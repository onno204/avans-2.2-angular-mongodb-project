export const environment = {
  production: true,
  apiUrl: "https://avans-app-2-2-backend.herokuapp.com/api/v1/"
};
